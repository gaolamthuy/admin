const { execSync } = require("child_process");
const fs = require("fs-extra");
const path = require("path");

// Create a timestamp for unique folder name
const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
const appDirName = `app-${timestamp}`;

// Define directories
const buildDir = path.join(__dirname, "build");
const distDir = path.join(__dirname, "dist");
const appDir = path.join(distDir, appDirName);

// Clean up and prepare directories
console.log("Setting up build directories...");
try {
  // Create directories
  fs.ensureDirSync(distDir);
  fs.ensureDirSync(appDir);
} catch (error) {
  console.error("Error during directory setup:", error);
  process.exit(1);
}

// Build React app
console.log("Building React app...");
try {
  execSync("npx react-scripts build", { stdio: "inherit" });
} catch (error) {
  console.error("Error building React app:", error);
  process.exit(1);
}

// Copy build folder to app directory
console.log(`Copying build folder to dist/${appDirName}...`);
try {
  fs.copySync(buildDir, path.join(appDir, "build"));
} catch (error) {
  console.error("Error copying build folder:", error);
  process.exit(1);
}

// Fix paths in index.html for Electron
console.log("Fixing resource paths in index.html for Electron...");
try {
  const indexPath = path.join(appDir, "build", "index.html");
  if (fs.existsSync(indexPath)) {
    let indexContent = fs.readFileSync(indexPath, "utf8");

    // Replace absolute paths (starting with /) with relative paths (./)
    indexContent = indexContent.replace(/href="\//g, 'href="./');
    indexContent = indexContent.replace(/src="\//g, 'src="./');

    fs.writeFileSync(indexPath, indexContent);
    console.log("Successfully fixed resource paths in index.html");
  } else {
    console.warn("Warning: index.html not found, could not fix resource paths");
  }
} catch (error) {
  console.error("Error fixing resource paths:", error);
  console.log("Continuing with build anyway...");
}

// Copy main.js, preload.js, and printer.js
console.log(`Copying main files to dist/${appDirName}...`);
try {
  fs.copySync("main.js", path.join(appDir, "main.js"));
  fs.copySync("preload.js", path.join(appDir, "preload.js"));
  fs.copySync("printer.js", path.join(appDir, "printer.js"));
} catch (error) {
  console.error("Error copying main files:", error);
  process.exit(1);
}

// Create a production package.json with only needed dependencies
const packageJson = {
  name: "gaolamthuy-pos",
  version: "1.0.0",
  description: "POS app for Gao Lam Thuy",
  main: "main.js",
  scripts: {
    start: "electron .",
  },
  dependencies: {
    "@supabase/supabase-js": "^2.49.4",
    axios: "^1.6.8",
    "electron-is-dev": "^3.0.1",
    qrcode: "^1.5.4",
  },
  devDependencies: {
    electron: "^35.2.0",
  },
};

// Write production package.json
fs.writeFileSync(
  path.join(appDir, "package.json"),
  JSON.stringify(packageJson, null, 2)
);

// Create a batch file to install dependencies and run the app
const setupBatchContent = `@echo off
echo Installing dependencies...
cd ${appDirName}
npm install
echo Done installing dependencies.
echo.
echo To run the application, use run_app.bat
`;

const runBatchContent = `@echo off
echo Starting Gao Lam Thuy POS...
cd ${appDirName}
npm start
`;

// Write batch files
fs.writeFileSync(path.join(distDir, "setup.bat"), setupBatchContent);
fs.writeFileSync(path.join(distDir, "run_app.bat"), runBatchContent);

// Create a README file with instructions
const readmeContent = `# Gao Lam Thuy POS Application

## Installation Instructions
1. Run setup.bat ONCE to install all required dependencies
2. Whenever you want to use the application, run run_app.bat

## Troubleshooting
If you encounter any issues:
- Make sure you've run setup.bat first
- Make sure you have Node.js installed
- Check that your firewall isn't blocking the application

## Contact
For support, contact: support@gaolamthuy.vn
`;

fs.writeFileSync(path.join(distDir, "README.md"), readmeContent);

console.log("Build completed successfully!");
console.log("");
console.log("==========================================");
console.log(`Your application is in dist/${appDirName}`);
console.log(
  "IMPORTANT: You need to run setup.bat ONCE to install dependencies"
);
console.log("Then you can run the app using run_app.bat anytime");
console.log("==========================================");
console.log("");
console.log("Both files are in your dist directory");
