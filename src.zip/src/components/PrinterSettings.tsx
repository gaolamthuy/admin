import React, { useState, useEffect } from "react";
import {
  Card,
  Select,
  Form,
  Row,
  Col,
  Typography,
  Spin,
  message,
  Button,
  Space,
  Input,
  Divider,
} from "antd";
import { PrinterOutlined } from "@ant-design/icons";
import { PrinterInfo, PrinterConfig } from "../types/electron";
import {
  getAvailablePrinters,
  getPrinterConfig,
  updatePrinterConfig,
  printDocument,
} from "../utils/printUtils";

const { Title } = Typography;
const { Option } = Select;

// Sample HTML for test prints
const TEST_PRINTS = {
  k80: `
    <div style="font-family: monospace; width: 80mm;">
      <h3 style="text-align: center;">Test Receipt (K80)</h3>
      <p>This is a test print for the K80 thermal printer.</p>
      <p>Date: ${new Date().toLocaleString()}</p>
      <p>If you can read this clearly, your printer is working correctly.</p>
      <hr/>
      <p style="text-align: center;">*** End of Test ***</p>
    </div>
  `,
  a4: `
    <div style="padding: 20px;">
      <h2>Test Print (A4)</h2>
      <p>This is a test print for the A4 printer.</p>
      <p>Date: ${new Date().toLocaleString()}</p>
      <p>If you can read this clearly, your printer is working correctly.</p>
      <hr/>
      <p style="text-align: center;">*** End of Test ***</p>
    </div>
  `,
  label: `
    <div style="width: 100mm; padding: 10px; text-align: center;">
      <h3>Test Label</h3>
      <p>Test Print</p>
      <p>${new Date().toLocaleString()}</p>
    </div>
  `,
};

const PrinterSettings: React.FC = () => {
  const [printers, setPrinters] = useState<PrinterInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [manualInput, setManualInput] = useState<{ [key: string]: boolean }>({
    printInvoiceK80: false,
    printInvoiceA4: false,
    printLabel: false,
  });
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>({
    printInvoiceK80: "",
    printInvoiceA4: "",
    printLabel: "",
  });

  // Helper function to clean printer name - remove all ": " prefixes and clean up nested parentheses
  const cleanPrinterName = (name: string) => {
    if (!name) return "";
    // Remove all instances of ": " and trim
    return name.replace(/:\s+/g, "").trim();
  };

  // Helper function to get display name
  const getDisplayName = (printer: PrinterInfo) => {
    const name = cleanPrinterName(printer.name);
    let displayName = "";

    // Extract the driver name from the description
    const driverMatch = printer.description?.match(/Driver:\s*:?\s*([^|]+)/);
    const driverName = driverMatch ? cleanPrinterName(driverMatch[1]) : "";

    // Only add driver name if it's different from the printer name and not empty
    if (driverName && driverName !== name) {
      displayName = `${name} (${driverName})`;
    } else {
      displayName = name;
    }

    return displayName;
  };

  // Helper function to get actual printer name for configuration
  const getActualPrinterName = (printer: PrinterInfo) => {
    return cleanPrinterName(printer.name);
  };

  useEffect(() => {
    loadPrinterConfig();
  }, []);

  const loadPrinterConfig = async () => {
    try {
      const config = await getPrinterConfig();
      const availablePrinters = await getAvailablePrinters();

      // Clean printer names in config
      setPrinterConfig({
        printInvoiceK80: cleanPrinterName(config.printInvoiceK80 || ""),
        printInvoiceA4: cleanPrinterName(config.printInvoiceA4 || ""),
        printLabel: cleanPrinterName(config.printLabel || ""),
      });

      // Clean printer names in printer list
      setPrinters(
        availablePrinters.map((printer) => ({
          ...printer,
          name: cleanPrinterName(printer.name),
          displayName: cleanPrinterName(printer.displayName || printer.name),
        }))
      );

      setLoading(false);
    } catch (error) {
      console.error("Error loading printer configuration:", error);
      message.error("Failed to load printer configuration");
      setLoading(false);
    }
  };

  const handlePrinterChange = async (
    type: keyof PrinterConfig,
    value: string
  ) => {
    try {
      const response = await updatePrinterConfig(type, value);
      if (!response.success) {
        message.error("Không thể cập nhật cấu hình máy in. Vui lòng thử lại.");
        return;
      }
      message.success("Đã cập nhật cấu hình máy in thành công.");
      await loadPrinterConfig();
    } catch (error) {
      console.error("Error updating printer config:", error);
      message.error("Đã xảy ra lỗi khi cập nhật cấu hình máy in.");
    }
  };

  const handleTestPrint = async (type: "k80" | "a4" | "label") => {
    try {
      const printerId =
        type === "k80"
          ? "printInvoiceK80"
          : type === "a4"
          ? "printInvoiceA4"
          : "printLabel";

      if (!printerConfig[printerId]) {
        message.error(
          `Please select a printer for ${type.toUpperCase()} first`
        );
        return;
      }

      const testHtml = TEST_PRINTS[type];

      message.loading(`Testing ${type.toUpperCase()} printer...`, 1);
      const result = await printDocument(printerId, testHtml);

      if (result.success) {
        message.success(`Test print sent to ${type.toUpperCase()} printer`);
      } else {
        throw new Error(result.error || "Unknown error");
      }
    } catch (error) {
      console.error(`Error testing ${type} printer:`, error);
      message.error(`Failed to test ${type.toUpperCase()} printer`);
    }
  };

  const toggleManualInput = (type: keyof PrinterConfig) => {
    setManualInput((prev) => ({
      ...prev,
      [type]: !prev[type],
    }));
  };

  return (
    <Card>
      <Title level={4}>
        <PrinterOutlined /> Printer Settings
      </Title>
      {loading ? (
        <div style={{ textAlign: "center", padding: "20px" }}>
          <Spin size="large" />
        </div>
      ) : (
        <Form layout="vertical">
          <Row gutter={[16, 16]}>
            <Col span={8}>
              <Form.Item
                label="K80 Printer (Receipt)"
                help="Used for thermal receipt printing"
              >
                <Space direction="vertical" style={{ width: "100%" }}>
                  {manualInput.printInvoiceK80 ? (
                    <Input
                      value={printerConfig.printInvoiceK80}
                      onChange={(e) =>
                        handlePrinterChange("printInvoiceK80", e.target.value)
                      }
                      placeholder="Enter printer name"
                      addonAfter={
                        <Button
                          type="link"
                          onClick={() => toggleManualInput("printInvoiceK80")}
                          style={{ padding: 0 }}
                        >
                          Use List
                        </Button>
                      }
                    />
                  ) : (
                    <Select
                      value={printerConfig.printInvoiceK80}
                      onChange={(value: string) =>
                        handlePrinterChange("printInvoiceK80", value)
                      }
                      placeholder="Select K80 printer"
                      style={{ width: "100%" }}
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider style={{ margin: "8px 0" }} />
                          <Button
                            type="link"
                            onClick={() => toggleManualInput("printInvoiceK80")}
                            style={{ padding: "8px" }}
                          >
                            Manual Input
                          </Button>
                        </>
                      )}
                    >
                      <Option value="">None</Option>
                      {printers.map((printer) => (
                        <Option
                          key={getActualPrinterName(printer)}
                          value={getActualPrinterName(printer)}
                        >
                          {getDisplayName(printer)}
                        </Option>
                      ))}
                    </Select>
                  )}
                  <Button
                    onClick={() => handleTestPrint("k80")}
                    disabled={!printerConfig.printInvoiceK80}
                  >
                    Test K80 Printer
                  </Button>
                </Space>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="A4 Printer (Full Page)"
                help="Used for full-page invoice printing"
              >
                <Space direction="vertical" style={{ width: "100%" }}>
                  {manualInput.printInvoiceA4 ? (
                    <Input
                      value={printerConfig.printInvoiceA4}
                      onChange={(e) =>
                        handlePrinterChange("printInvoiceA4", e.target.value)
                      }
                      placeholder="Enter printer name"
                      addonAfter={
                        <Button
                          type="link"
                          onClick={() => toggleManualInput("printInvoiceA4")}
                          style={{ padding: 0 }}
                        >
                          Use List
                        </Button>
                      }
                    />
                  ) : (
                    <Select
                      value={printerConfig.printInvoiceA4}
                      onChange={(value: string) =>
                        handlePrinterChange("printInvoiceA4", value)
                      }
                      placeholder="Select A4 printer"
                      style={{ width: "100%" }}
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider style={{ margin: "8px 0" }} />
                          <Button
                            type="link"
                            onClick={() => toggleManualInput("printInvoiceA4")}
                            style={{ padding: "8px" }}
                          >
                            Manual Input
                          </Button>
                        </>
                      )}
                    >
                      <Option value="">None</Option>
                      {printers.map((printer) => (
                        <Option
                          key={getActualPrinterName(printer)}
                          value={getActualPrinterName(printer)}
                        >
                          {getDisplayName(printer)}
                        </Option>
                      ))}
                    </Select>
                  )}
                  <Button
                    onClick={() => handleTestPrint("a4")}
                    disabled={!printerConfig.printInvoiceA4}
                  >
                    Test A4 Printer
                  </Button>
                </Space>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="Label Printer"
                help="Used for product label printing"
              >
                <Space direction="vertical" style={{ width: "100%" }}>
                  {manualInput.printLabel ? (
                    <Input
                      value={printerConfig.printLabel}
                      onChange={(e) =>
                        handlePrinterChange("printLabel", e.target.value)
                      }
                      placeholder="Enter printer name"
                      addonAfter={
                        <Button
                          type="link"
                          onClick={() => toggleManualInput("printLabel")}
                          style={{ padding: 0 }}
                        >
                          Use List
                        </Button>
                      }
                    />
                  ) : (
                    <Select
                      value={printerConfig.printLabel}
                      onChange={(value: string) =>
                        handlePrinterChange("printLabel", value)
                      }
                      placeholder="Select label printer"
                      style={{ width: "100%" }}
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider style={{ margin: "8px 0" }} />
                          <Button
                            type="link"
                            onClick={() => toggleManualInput("printLabel")}
                            style={{ padding: "8px" }}
                          >
                            Manual Input
                          </Button>
                        </>
                      )}
                    >
                      <Option value="">None</Option>
                      {printers.map((printer) => (
                        <Option
                          key={getActualPrinterName(printer)}
                          value={getActualPrinterName(printer)}
                        >
                          {getDisplayName(printer)}
                        </Option>
                      ))}
                    </Select>
                  )}
                  <Button
                    onClick={() => handleTestPrint("label")}
                    disabled={!printerConfig.printLabel}
                  >
                    Test Label Printer
                  </Button>
                </Space>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      )}
    </Card>
  );
};

export default PrinterSettings;
