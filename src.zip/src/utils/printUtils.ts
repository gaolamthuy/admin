import { PrinterConfig, PrintResponse, PrinterInfo } from "../types/electron";

export const getAvailablePrinters = async (): Promise<PrinterInfo[]> => {
  try {
    if (!window.electron?.printer) {
      return [];
    }
    const result = await window.electron.printer.getAvailablePrinters();
    if (!result.success) {
      throw new Error(result.error);
    }
    return result.printers;
  } catch (error) {
    console.error("Error getting available printers:", error);
    return [];
  }
};

export const getPrinterConfig = async (): Promise<PrinterConfig> => {
  if (!window.electron?.printer) {
    return {
      printInvoiceK80: "", // K80 thermal printer
      printInvoiceA4: "", // A4 regular printer
      printLabel: "", // Label printer
    };
  }
  return await window.electron.printer.getPrinterConfig();
};

export const updatePrinterConfig = async (
  type: keyof PrinterConfig,
  printerName: string
): Promise<PrintResponse> => {
  try {
    if (!window.electron?.printer) {
      return { success: false, error: "Electron printer not available" };
    }
    return await window.electron.printer.updatePrinterConfig(type, printerName);
  } catch (error) {
    console.error("Error updating printer config:", error);
    return { success: false, error: String(error) };
  }
};

/**
 * Prints document using the specified printer type
 * @param type - The printer type (printInvoice, printInvoiceExtra, printLabel)
 * @param html - The HTML content to print
 * @returns A promise that resolves to a success or error response
 */
export const printDocument = async (
  type: keyof PrinterConfig,
  html: string
): Promise<PrintResponse> => {
  try {
    if (!window.electron?.printer) {
      return { success: false, error: "Electron printer not available" };
    }

    const config = await getPrinterConfig();
    if (!config[type]) {
      return { success: false, error: `Printer not configured for ${type}` };
    }

    window.electron.printer.print({ type, html });
    return { success: true };
  } catch (error) {
    console.error("Error printing document:", error);
    return { success: false, error: String(error) };
  }
};
