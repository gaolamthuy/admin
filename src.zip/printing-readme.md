# POS Printing Functionality

This document provides instructions on how to use and configure the printing functionality in the POS application.

## Overview

The POS application supports three types of printing:

1. **Receipt Printing (K80)** - For printing thermal receipts on K80 printers.
2. **Invoice Printing (A4)** - For printing full invoices on A4 printers.
3. **Label Printing (A7)** - For printing product labels on label printers.

## Printer Configuration

Before using the printing functionality, you need to configure your printers:

1. Navigate to the Settings page in the application.
2. Go to the "Printer Settings" section.
3. For each print function (Receipt, Invoice, Label), select the appropriate printer from the dropdown menu.
4. Click "Save" to apply the settings.

The application will save the printer configuration in the `printer-config.json` file located in the root directory of the application.

## Using the Print Functions in Your Code

### Import the Print Service

```typescript
import { printDocument } from "../services/printService";
```

### Print a Receipt

```typescript
// HTML content for the receipt
const receiptHtml = `
  <!DOCTYPE html>
  <html>
    <head>
      <style>
        body { font-family: Arial; width: 80mm; }
        /* Add more styles as needed */
      </style>
    </head>
    <body>
      <!-- Receipt content -->
      <h1>Your Receipt</h1>
      <!-- More receipt content -->
    </body>
  </html>
`;

// Print the receipt
const printResult = await printDocument("printInvoice", receiptHtml);

// Handle the result
if (printResult.success) {
  console.log("Receipt printed successfully");
} else {
  console.error("Failed to print receipt:", printResult.error);
}
```

### Print an Invoice

```typescript
// HTML content for the invoice
const invoiceHtml = `
  <!DOCTYPE html>
  <html>
    <head>
      <style>
        body { font-family: Arial; width: 210mm; height: 297mm; }
        /* Add more styles as needed */
      </style>
    </head>
    <body>
      <!-- Invoice content -->
      <h1>Invoice</h1>
      <!-- More invoice content -->
    </body>
  </html>
`;

// Print the invoice
const printResult = await printDocument("printInvoiceExtra", invoiceHtml);

// Handle the result
if (printResult.success) {
  console.log("Invoice printed successfully");
} else {
  console.error("Failed to print invoice:", printResult.error);
}
```

### Print a Label

```typescript
// HTML content for the label
const labelHtml = `
  <!DOCTYPE html>
  <html>
    <head>
      <style>
        body { font-family: Arial; width: 74mm; height: 105mm; }
        /* Add more styles as needed */
      </style>
    </head>
    <body>
      <!-- Label content -->
      <h1>Product Label</h1>
      <!-- More label content -->
    </body>
  </html>
`;

// Print the label
const printResult = await printDocument("printLabel", labelHtml);

// Handle the result
if (printResult.success) {
  console.log("Label printed successfully");
} else {
  console.error("Failed to print label:", printResult.error);
}
```

## Error Handling

The print functions return a `PrintResponse` object with the following properties:

```typescript
interface PrintResponse {
  success: boolean;
  error?: string;
}
```

If `success` is `false`, the `error` property will contain a description of the error.

Common error scenarios:

- Printer not configured for the specified print type
- Configured printer not found on the system
- Printing failed due to printer issues (out of paper, offline, etc.)

## Printer Configuration API

The print service provides additional functions for working with printer configuration:

### Get Printer Configuration

```typescript
import { getPrinterConfig } from "../services/printService";

const config = await getPrinterConfig();
console.log("Current printer configuration:", config);
```

### Update Printer Configuration

```typescript
import { updatePrinterConfig } from "../services/printService";

// Update the printer for receipt printing
const result = await updatePrinterConfig("printInvoice", "Epson TM-T88V");

if (result.success) {
  console.log("Printer configuration updated successfully");
} else {
  console.error("Failed to update printer configuration:", result.error);
}
```

### Get Available Printers

```typescript
import { getAvailablePrinters } from "../services/printService";

const printers = await getAvailablePrinters();
console.log("Available printers:", printers);
```

## Troubleshooting

If you encounter issues with printing:

1. Check that the printer is properly connected and turned on.
2. Verify that the printer configuration is correctly set up.
3. Check for error messages in the application logs.
4. Make sure the printer drivers are installed and up to date.
5. Test the printer using the operating system's print dialog.

## Notes for Developers

- The printing functionality uses Electron's native printing capabilities through the `webContents.print()` API.
- The printer configuration is stored in the `printer-config.json` file.
- The HTML content provided to the print functions should include appropriate CSS for the target printer and page size.
- All print operations are performed silently (without showing a print dialog).
- If a printer is not configured for a specific print type, the corresponding print function will return an error.

## Example Code

For a complete example of how to use the printing functionality, see the `PrintExample.tsx` file in the `src/examples` directory.
