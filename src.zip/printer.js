const fs = require("fs");
const path = require("path");
const { dialog } = require("electron");

let printerConfig = {};

/**
 * Load printer configuration from JSON file
 */
function loadPrinterConfig() {
  try {
    const configPath = path.join(__dirname, "printer-config.json");

    // Create a proper default configuration
    const defaultConfig = {
      printInvoiceK80: "", // K80 thermal printer
      printInvoiceA4: "", // A4 regular printer
      printLabel: "", // Label printer
    };

    if (fs.existsSync(configPath)) {
      try {
        const configData = fs.readFileSync(configPath, "utf8");
        const parsedConfig = JSON.parse(configData);

        // Validate the config has the required fields
        if (typeof parsedConfig === "object" && parsedConfig !== null) {
          printerConfig = {
            ...defaultConfig, // Ensure all defaults exist
            ...parsedConfig, // Override with stored values
          };
          console.log("Printer configuration loaded successfully");
        } else {
          console.warn("Invalid printer configuration format, using defaults");
          printerConfig = defaultConfig;
          savePrinterConfig();
        }
      } catch (parseError) {
        console.error("Failed to parse printer configuration:", parseError);
        printerConfig = defaultConfig;
        savePrinterConfig();
      }
    } else {
      console.warn(
        "Printer configuration file not found. Creating default configuration."
      );
      printerConfig = defaultConfig;
      savePrinterConfig();
    }
  } catch (error) {
    console.error("Failed to load printer configuration:", error);
    printerConfig = {
      printInvoiceK80: "", // K80 thermal printer
      printInvoiceA4: "", // A4 regular printer
      printLabel: "", // Label printer
    };
  }

  console.log("Current printer configuration:", printerConfig);
}

/**
 * Save printer configuration to JSON file
 */
function savePrinterConfig() {
  try {
    const configPath = path.join(__dirname, "printer-config.json");
    fs.writeFileSync(
      configPath,
      JSON.stringify(printerConfig, null, 2),
      "utf8"
    );
    console.log("Printer configuration saved successfully");
  } catch (error) {
    console.error("Failed to save printer configuration:", error);
  }
}

/**
 * Print document using specified printer type
 * @param {string} type - Type of print job (printInvoice, printInvoiceExtra, printLabel)
 * @param {Electron.WebContents} webContents - WebContents object to print
 * @param {string} html - HTML content to print (optional, if not using webContents)
 * @returns {Promise<Object>} - Result of print operation
 */
async function printDocument(type, webContents, html = null) {
  return new Promise(async (resolve, reject) => {
    try {
      // Check if printer type exists in config
      if (!printerConfig[type]) {
        const errorMsg = `Printer type "${type}" not configured`;
        console.error(errorMsg);
        return resolve({ success: false, error: errorMsg });
      }

      // Get device name from config
      let deviceName = printerConfig[type];
      if (!deviceName) {
        const errorMsg = `No printer configured for ${type}`;
        console.error(errorMsg);
        return resolve({ success: false, error: errorMsg });
      }

      // Use the exact printer name without modification
      deviceName = deviceName.trim();

      console.log(`[DEBUG] Using printer "${deviceName}" for type "${type}"`);

      // Base print options
      const options = {
        silent: true,
        printBackground: true,
        deviceName: deviceName,
        // Force silent mode for all print jobs
        cancelId: 0, // Setting cancelId to 0 forces silent mode in Electron
        margins: { marginType: "none" }, // Remove margins
      };

      // Add specific settings based on print type
      if (type === "printLabel") {
        // A7 paper size (74mm x 105mm)
        options.pageSize = {
          width: 74000,
          height: 105000,
        };
      } else if (type === "printInvoiceK80") {
        // K80 receipt printer (80mm width)
        options.pageSize = {
          width: 80000,
          height: 210000,
        };
      } else if (type === "printInvoiceA4") {
        // A4 paper size (210mm x 297mm)
        // A5 paper size (148mm x 210mm)
        options.pageSize = {
          width: 148000,
          height: 210000,
        };
      }

      console.log("[DEBUG] Print options:", JSON.stringify(options, null, 2));

      // Print the document
      if (html) {
        try {
          // Create a hidden window for printing HTML content
          const { BrowserWindow } = require("electron");
          const printWindow = new BrowserWindow({
            width: 800,
            height: 600,
            show: false,
          });

          // Load the HTML content
          await printWindow.loadURL(
            `data:text/html;charset=utf-8,${encodeURIComponent(html)}`
          );

          // Wait for window to be ready
          await new Promise((resolve) => setTimeout(resolve, 1000));

          // Get the window's current list of printers
          try {
            const printers = printWindow.webContents.getPrinters();
            console.log(
              "[DEBUG] Available printers:",
              printers.map((p) => p.name).join(", ")
            );

            // Check if our printer exists
            const printerExists = printers.some((p) => p.name === deviceName);
            if (!printerExists) {
              console.log(
                `[WARNING] Printer "${deviceName}" not found in available printers list`
              );
            }
          } catch (printerListError) {
            console.error(
              "[DEBUG] Error getting printer list:",
              printerListError
            );
          }

          // Print
          console.log("[DEBUG] Starting print job...");
          printWindow.webContents.print(options, (success, errorType) => {
            printWindow.close();

            if (!success) {
              const errorMsg = `Print failed: ${errorType}`;
              console.error("[DEBUG]", errorMsg);
              resolve({ success: false, error: errorMsg });
            } else {
              console.log(`[DEBUG] Print job "${type}" completed successfully`);
              resolve({ success: true });
            }
          });
        } catch (printError) {
          console.error("[DEBUG] Print error:", printError);
          resolve({ success: false, error: printError.message });
        }
      } else if (webContents) {
        // Print from provided webContents
        webContents.print(options, (success, errorType) => {
          if (!success) {
            const errorMsg = `Print failed: ${errorType}`;
            console.error("[DEBUG]", errorMsg);
            resolve({ success: false, error: errorMsg });
          } else {
            console.log(`[DEBUG] Print job "${type}" completed successfully`);
            resolve({ success: true });
          }
        });
      } else {
        const errorMsg =
          "Neither HTML content nor WebContents provided for printing";
        console.error("[DEBUG]", errorMsg);
        resolve({ success: false, error: errorMsg });
      }
    } catch (error) {
      console.error("[DEBUG] Unexpected error in printDocument:", error);
      resolve({ success: false, error: error.message });
    }
  });
}

/**
 * Get the current printer configuration
 * @returns {Object} - Printer configuration
 */
function getPrinterConfig() {
  return printerConfig;
}

/**
 * Update printer configuration
 * @param {string} type - Printer type to update
 * @param {string} printerName - New printer name
 */
function updatePrinterConfig(type, printerName) {
  printerConfig[type] = printerName;
  savePrinterConfig();
  return { success: true };
}

/**
 * Check if a printer is installed on the system (without using webContents)
 * This is an alternative to webContents.getPrinters() which is causing issues
 * @returns {boolean} True if the printer exists
 */
function checkPrinterAvailability() {
  try {
    console.log("Checking for available printers in the system");
    // Get the OS printers using platform-specific methods
    // This is just a placeholder - we don't actually check,
    // but we log the information that would be useful for debugging
    const platform = process.platform;
    console.log(`Running on platform: ${platform}`);

    // For Windows, we could use PowerShell to list printers:
    // exec('powershell Get-Printer | Format-List Name')

    // For now, we'll just log what we've configured
    console.log("Currently configured printers:");
    for (const [type, name] of Object.entries(printerConfig)) {
      console.log(`- ${type}: "${name || "(not set)"}"`);
    }

    return true;
  } catch (error) {
    console.error("Error checking printer availability:", error);
    return false;
  }
}

// Load printer configuration on module import
loadPrinterConfig();

// Call this on load to report printer information
checkPrinterAvailability();

module.exports = {
  printDocument,
  getPrinterConfig,
  updatePrinterConfig,
  loadPrinterConfig,
  checkPrinterAvailability,
};
