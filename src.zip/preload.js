const { contextBridge, ipcRenderer } = require("electron");

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld("electron", {
  ipcRenderer: {
    send: (channel, data) => {
      // List of allowed channels for send
      const validSendChannels = ["print", "print-invoice"];
      if (validSendChannels.includes(channel)) {
        return ipcRenderer.send(channel, data);
      } else {
        console.warn(`Channel '${channel}' is not whitelisted for sending`);
      }
    },
    on: (channel, func) => {
      // List of allowed channels for receiving
      const validReceiveChannels = ["print-response"];
      if (validReceiveChannels.includes(channel)) {
        return ipcRenderer.on(channel, func);
      } else {
        console.warn(`Channel '${channel}' is not whitelisted for receiving`);
      }
    },
    removeAllListeners: (channel) => {
      const validChannels = ["print-response"];
      if (validChannels.includes(channel)) {
        ipcRenderer.removeAllListeners(channel);
      }
    },
  },
  printer: {
    // Print functions
    print: (data) => {
      return ipcRenderer.send("print", data);
    },

    // Get printer configuration
    getPrinterConfig: async () => {
      return ipcRenderer.invoke("get-printer-config");
    },

    // Update printer configuration
    updatePrinterConfig: async (type, printerName) => {
      return ipcRenderer.invoke("update-printer-config", { type, printerName });
    },

    // Get available printers
    getAvailablePrinters: async () => {
      return ipcRenderer.invoke("get-available-printers");
    },

    // Event listeners
    onPrintResponse: (callback) => {
      ipcRenderer.on("print-response", (event, ...args) => callback(...args));
    },

    // Remove event listeners
    removeAllListeners: (channel) => {
      ipcRenderer.removeAllListeners(channel);
    },
  },
});
