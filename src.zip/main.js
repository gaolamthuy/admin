const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const isDev = require("electron-is-dev");
const printer = require("./printer");
const { exec } = require("child_process");

// Process any command line arguments
processCommandLineArgs();

// Handle command line arguments and run special commands
function processCommandLineArgs() {
  const args = process.argv.slice(2);

  // Check for --list-printers argument
  if (args.includes("--list-printers")) {
    console.log("Listing system printers...");
    listSystemPrinters()
      .then(() => {
        // Exit after listing printers if it was explicitly requested
        if (!args.includes("--keep-running")) {
          process.exit(0);
        }
      })
      .catch((err) => {
        console.error("Error listing printers:", err);
        process.exit(1);
      });
  }
}

// Function to list system printers using OS-specific commands
async function listSystemPrinters() {
  return new Promise((resolve, reject) => {
    let command = "";

    // Determine the command based on the OS
    if (process.platform === "win32") {
      command =
        'powershell -command "Get-Printer | Select-Object Name,DriverName,PortName | Format-List"';
    } else if (process.platform === "darwin") {
      command = "lpstat -p | awk '{print $2}'";
    } else if (process.platform === "linux") {
      command = "lpstat -a";
    } else {
      reject(new Error(`Unsupported platform: ${process.platform}`));
      return;
    }

    // Execute the command
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error executing command: ${error.message}`);
        reject(error);
        return;
      }

      if (stderr) {
        console.error(`Command stderr: ${stderr}`);
      }

      console.log("============ SYSTEM PRINTERS ============");
      console.log(stdout);
      console.log("========================================");

      // Also print our current printer configuration
      console.log("Current printer configuration:");
      const printerConfig = printer.getPrinterConfig();
      console.log(JSON.stringify(printerConfig, null, 2));
      console.log("========================================");

      resolve(stdout);
    });
  });
}

// Suppress DBUS errors on WSL - this is commonly causing SIGTRAP crashes
if (process.platform === "linux") {
  process.env.DBUS_SYSTEM_BUS_ADDRESS = "unix:path=/dev/null";
}

let mainWindow;

function createWindow() {
  // Create the browser window with updated settings
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      preload: path.join(__dirname, "preload.js"),
    },
  });

  // Always load index.html from the build directory in production mode
  const indexPath = path.join(__dirname, "build", "index.html");
  console.log("Loading from path:", indexPath);

  // Check if file exists first
  if (require("fs").existsSync(indexPath)) {
    console.log("Index.html file found, loading...");
    mainWindow.loadFile(indexPath);
    console.log("File loaded successfully");
  } else {
    console.error("ERROR: File not found: " + indexPath);
    mainWindow.loadURL(
      `data:text/html,<h1>Error</h1><p>Could not find the application files at: ${indexPath}</p>`
    );
  }

  // Open DevTools when needed for debugging
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // *** Đăng ký handler IPC NGAY SAU KHI mainWindow được tạo ***
  ipcMain.handle("get-available-printers", async () => {
    try {
      // Use the listSystemPrinters function we already have
      const printerList = await listSystemPrinters();

      // Parse the output based on the OS
      let printers = [];

      if (process.platform === "win32") {
        // Parse Windows PowerShell output more thoroughly
        const printers = new Map(); // Use Map to handle duplicates
        let currentPrinter = null;
        const lines = printerList.split("\n");

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine) continue;

          if (trimmedLine.startsWith("Name")) {
            if (currentPrinter) {
              // Only add if we don't have this printer yet, or if we do but this one has more info
              const existingPrinter = printers.get(currentPrinter.name);
              if (
                !existingPrinter ||
                currentPrinter.description.length >
                  existingPrinter.description.length
              ) {
                printers.set(currentPrinter.name, currentPrinter);
              }
            }
            currentPrinter = {
              name: trimmedLine.substring(5).trim(),
              displayName: "",
              description: "",
              status: 0,
              isDefault: false,
            };
          } else if (trimmedLine.startsWith("DriverName")) {
            if (currentPrinter) {
              currentPrinter.displayName = `${
                currentPrinter.name
              } (${trimmedLine.substring(10).trim()})`;
              currentPrinter.description = `Driver: ${trimmedLine
                .substring(10)
                .trim()}`;
            }
          } else if (trimmedLine.startsWith("PortName")) {
            if (currentPrinter) {
              currentPrinter.description += ` | Port: ${trimmedLine
                .substring(8)
                .trim()}`;
            }
          }
        }

        // Add the last printer
        if (currentPrinter) {
          const existingPrinter = printers.get(currentPrinter.name);
          if (
            !existingPrinter ||
            currentPrinter.description.length >
              existingPrinter.description.length
          ) {
            printers.set(currentPrinter.name, currentPrinter);
          }
        }

        // Convert Map to array
        const uniquePrinters = Array.from(printers.values());
        console.log("Found unique printers:", uniquePrinters);

        return {
          success: true,
          printers: uniquePrinters,
        };
      } else if (process.platform === "darwin") {
        // Parse macOS output
        const lines = printerList.split("\n");
        printers = lines
          .filter((line) => line.trim())
          .map((line) => ({
            name: line.trim(),
            displayName: line.trim(),
            description: "",
            status: 0,
            isDefault: false,
          }));
      } else {
        // Parse Linux output
        const lines = printerList.split("\n");
        printers = lines
          .filter((line) => line.trim())
          .map((line) => {
            const name = line.split(" ")[0];
            return {
              name,
              displayName: name,
              description: "",
              status: 0,
              isDefault: false,
            };
          });
      }

      console.log("Found printers:", printers);
      return {
        success: true,
        printers,
      };
    } catch (error) {
      console.error("Error getting printers:", error);
      return {
        success: false,
        error: error.message,
        printers: [],
      };
    }
  });
  // ***********************************************************

  // Set up event handler for window closed
  mainWindow.on("closed", () => {
    mainWindow = null;
    // Quan trọng: Gỡ bỏ handler khi cửa sổ đóng để tránh lỗi
    ipcMain.removeHandler("get-available-printers");
  });
}

// When Electron is ready, create the window
app.whenReady().then(createWindow);

// Quit the app when all windows are closed (except on macOS)
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

// On macOS, recreate the window when the dock icon is clicked
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Handle general print requests
ipcMain.on("print", async (event, data) => {
  if (!mainWindow) {
    event.reply("print-response", {
      success: false,
      error: "Main window not available",
    });
    return;
  }

  try {
    const { type, html } = data;

    if (!type) {
      event.reply("print-response", {
        success: false,
        error: "Print type not specified",
      });
      return;
    }

    let result;

    if (html) {
      // Print from HTML content
      result = await printer.printDocument(type, mainWindow.webContents, html);
    } else {
      // Print current window content
      result = await printer.printDocument(type, mainWindow.webContents);
    }

    event.reply("print-response", result);

    // Show error dialog for failed prints
    if (!result.success) {
      dialog.showMessageBox(mainWindow, {
        type: "error",
        title: "Print Error",
        message: `Failed to print: ${result.error}`,
        buttons: ["OK"],
      });
    }
  } catch (error) {
    console.error("Error in print handler:", error);
    event.reply("print-response", {
      success: false,
      error: error.message || "Unknown error occurred",
    });

    dialog.showMessageBox(mainWindow, {
      type: "error",
      title: "Print Error",
      message: `An unexpected error occurred: ${
        error.message || "Unknown error"
      }`,
      buttons: ["OK"],
    });
  }
});

// Get printer configuration
ipcMain.handle("get-printer-config", async () => {
  return printer.getPrinterConfig();
});

// Update printer configuration
ipcMain.handle("update-printer-config", async (event, data) => {
  const { type, printerName } = data;
  return printer.updatePrinterConfig(type, printerName);
});

// Handle invoice print requests
ipcMain.on("print-invoice", async (event, data) => {
  if (!mainWindow) {
    console.error("Main window not available for printing invoice");
    return;
  }

  try {
    const { html, printerType } = data;

    if (!html) {
      console.error("No HTML content provided for invoice printing");
      return;
    }

    console.log("Received print-invoice request with HTML content");
    console.log("Using printer type:", printerType || "printInvoice (default)");

    // First try with the specified printer type or fallback to printInvoice
    let result = await printer.printDocument(
      printerType || "printInvoice",
      mainWindow.webContents,
      html
    );

    // If that fails and we have a specific error about deviceName, try with default printer
    if (
      !result.success &&
      result.error &&
      result.error.includes("Invalid deviceName")
    ) {
      console.log("Trying again without specifying a printer device");

      // Create a temporary config with empty device name to use system default
      const tempOptions = {
        silent: true,
        printBackground: true,
        // Don't set deviceName to use the system default
        pageSize: { width: 80000, height: 210000 }, // K80 receipt format
      };

      // Create a hidden window for printing HTML content with default printer
      const { BrowserWindow } = require("electron");
      const printWindow = new BrowserWindow({
        width: 800,
        height: 600,
        show: false,
      });

      try {
        // Load content and print
        printWindow.loadURL(
          `data:text/html;charset=utf-8,${encodeURIComponent(html)}`
        );

        // Create a promise-based version of the print operation
        result = await new Promise((resolve) => {
          printWindow.webContents.on("did-finish-load", () => {
            printWindow.webContents.print(tempOptions, (success, errorType) => {
              printWindow.close();
              if (!success) {
                const errorMsg = `Print failed: ${errorType}`;
                console.error(errorMsg);
                resolve({ success: false, error: errorMsg });
              } else {
                console.log(
                  "Print job completed successfully with default printer"
                );
                resolve({ success: true });
              }
            });
          });
        });
      } catch (printError) {
        console.error("Error in fallback printing:", printError);
        printWindow.close();
        result = { success: false, error: printError.message };
      }
    }

    // Log the result
    if (result.success) {
      console.log("Invoice printed successfully");
    } else {
      console.error("Failed to print invoice:", result.error);

      // Show error dialog for failed prints, but don't show for the deviceName error
      // which we've already tried to recover from
      if (!result.error.includes("Invalid deviceName")) {
        dialog.showMessageBox(mainWindow, {
          type: "error",
          title: "Print Error",
          message: `Failed to print invoice: ${result.error}`,
          buttons: ["OK"],
        });
      }
    }
  } catch (error) {
    console.error("Error in print-invoice handler:", error);

    dialog.showMessageBox(mainWindow, {
      type: "error",
      title: "Print Error",
      message: `An unexpected error occurred: ${
        error.message || "Unknown error"
      }`,
      buttons: ["OK"],
    });
  }
});
