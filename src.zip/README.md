# Gao Lam Thuy POS

A desktop Point of Sale (POS) application built with Electron and React, integrating with Supabase and KiotViet.

## Features

- Single-page POS interface with intuitive layout
- Product filtering by category and unit
- Easy product search and cart management
- Editable prices and quantities
- Customer search and selection
- Receipt preview and printing
- Integration   with KiotViet API for checkout
- Data synchronization with Supabase

## Screenshots

- Main POS page with product categories, units, and receipt preview
- Easy to use for daily operations

## Tech Stack

- **Frontend**: React, TypeScript, Ant Design
- **Desktop Framework**: Electron
- **Database**: Supabase
- **API Integration**: KiotViet

## Getting Started

### Prerequisites

- Node.js (>= 14)
- npm or yarn
- Supabase account with necessary tables
- KiotViet account with API access

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/gaolamthuy-pos.git
cd gaolamthuy-pos
```

2. Run the setup script:
```bash
npm run setup
```

3. Start the development server:
```bash
npm run dev
```

4. Log in with the default password:
```
admin123
```

### Required Database Tables

Your Supabase database should have these tables:
1. `kiotviet_products` - Product information
2. `kiotviet_customers` - Customer data
3. `kiotviet_branches` - Store branches
4. `kiotviet_staff` - Staff members
5. `system` - For storing KiotViet token

### Building for Production

```bash
npm run build
```

## Troubleshooting

If you encounter connection issues:
1. Check your Supabase credentials in the .env file
2. Ensure all required tables exist in your Supabase database
3. Verify your KiotViet token is valid and stored in the system table
4. Check the console for detailed error messages

## License

This project is licensed under the MIT License.

## Acknowledgements

- [Electron](https://www.electronjs.org/)
- [React](https://reactjs.org/)
- [Supabase](https://supabase.io/)
- [Ant Design](https://ant.design/) 